package fixture;

public class RunParameters
{
	public static final int WARMUP_ITERATIONS = 10;//10
	public static final int JNI_FUNCTION_ITERATIONS = 100;//100
}
