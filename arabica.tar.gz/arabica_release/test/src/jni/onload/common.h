extern void * handle;
extern char * libName;
